import random
rad_number = random.randint(1, 100)

while True:
    number = int(input('enter a number:'))
    if number == rad_number:
        print('right guess')
        break
    elif number > rad_number:
        print('choose lower number')
    else:
        print('choose higher number')
