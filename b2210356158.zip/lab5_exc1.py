def desired_for_odd(number):
    sum_of_odds = sum([n for n in range(1, number + 1) if n % 2 == 1])
    return sum_of_odds


def desired_for_even(number):
    even = ([i for i in range(1, number + 1) if i % 2 == 0])
    avg_evens = sum(even) / len(even)
    return avg_evens


a = int(input('enter a number:'))
print(f'sum of odds is {desired_for_odd(a)} and average of evens is {desired_for_even(a)}')