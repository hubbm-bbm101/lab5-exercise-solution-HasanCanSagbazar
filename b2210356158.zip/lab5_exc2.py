def is_mail(string):
    x = 0
    y = 0
    for i in string:
        if i == '@':
            x += 1
        elif i == '.':
            y += 1
    if x == 1 and y >= 1:
        return True
    else:
        return False


mail_checking = input("enter your mail:")
print(f'Is this a e-mail {is_mail(mail_checking)}')
